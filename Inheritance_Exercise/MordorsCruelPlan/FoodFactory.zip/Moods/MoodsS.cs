﻿namespace MordorsCruelPlan.Moods
{
    public class MoodsS
    {
        public virtual string Name => "Mood";
    }
}
