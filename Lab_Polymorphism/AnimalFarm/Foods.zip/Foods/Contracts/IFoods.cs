﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalFarm.Foods.Contracts
{
    public interface IFoods
    {
        int Quantity { get; }
    }
}
