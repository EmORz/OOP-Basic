﻿namespace BirthdayCelebrations.Contracts
{
    public interface IName
    {
        string Name { get; }
    }
}
