﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster_Training.Entities.Vechicles
{
    public class Semi : Vehicle
    {
        public Semi()
            : base(capacity: 10)
        {
        }
    }
}
