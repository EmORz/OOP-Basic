﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Engine
    {
        public int speed;
        public int power;

        public Engine(int power, int speed)
        {
            this.power = power;
            this.speed = speed;
        }

    }
}
