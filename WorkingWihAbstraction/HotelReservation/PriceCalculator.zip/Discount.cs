﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HotelReservation
{
    public enum Discount
    {
        None = 0,
        SecondVisit = 10,
        VIP = 20,
    }
}
