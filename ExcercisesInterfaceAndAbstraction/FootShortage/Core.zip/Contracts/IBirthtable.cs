﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FootShortage.Contracts
{
    public interface IBirthtable
    {
        DateTime Birthtime { get; }
    }
}
