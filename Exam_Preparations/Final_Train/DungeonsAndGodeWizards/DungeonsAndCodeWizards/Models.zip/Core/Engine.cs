﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Core
{
    public class Engine
    {
        public void Run()
        {
            //TODO Run
        }
    }
}
