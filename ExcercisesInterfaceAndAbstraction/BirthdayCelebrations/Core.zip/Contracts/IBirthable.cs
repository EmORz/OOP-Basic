﻿using System;

namespace BirthdayCelebrations.Contracts
{
    public interface IBirthable
    {
        DateTime Birthdate { get; }
    }
}
