﻿using MordorCruelPlan.Foods;

namespace MordorsCruelPlan.Foods
{
    public class HoneyCake : Food
    {
        private const int happiness = 5;
        
        public HoneyCake() : base(happiness)
        {
        }
    }
}
