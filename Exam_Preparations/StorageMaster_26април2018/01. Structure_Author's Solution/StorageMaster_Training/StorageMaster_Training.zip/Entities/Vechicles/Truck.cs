﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster_Training.Entities.Vechicles
{
    public class Truck : Vehicle
    {
        public Truck() 
            : base(capacity: 5)
        {
        }
    }
}
