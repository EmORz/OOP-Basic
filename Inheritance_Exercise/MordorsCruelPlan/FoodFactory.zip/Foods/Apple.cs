﻿using MordorCruelPlan.Foods;

namespace MordorsCruelPlan.Foods
{
    public class Apple : Food
    {
        private const int happiness = 1;

        public Apple() : base(happiness)
        {
        }
    }
}
