﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControlUpdate.Contracts
{
    public interface IBirthable
    {
        string Birthday { get; }
    }
}
