﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {

          







            //DateModifier d = new DateModifier();
            //string[] days = new string[2];
            //for (int i = 0; i <= 1; i++)
            //{
            //    days[i] = Console.ReadLine();               
            //}
            //d.TakeDate(days[0], days[1]);
            //d.Diff();





            //var count = int.Parse(Console.ReadLine());
            //OpinionPoll membersData = new OpinionPoll();

            //for (int i = 0; i < count; i++)
            //{
            //    string[] familyMembers = Console.ReadLine().Split();
            //    if (familyMembers.Length >1)
            //    {
            //        string name = familyMembers[0];
            //        int age = int.Parse(familyMembers[1]);
            //        membersData.AddPerson(age, name);
            //    }
            //    else
            //    {
            //        continue;
            //    }                
            //}
            //membersData.OldestThanThirty(); 

        }
    }
}
