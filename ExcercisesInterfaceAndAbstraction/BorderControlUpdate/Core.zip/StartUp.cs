﻿using BorderControlUpdate.Core;

namespace BorderControlUpdate
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
