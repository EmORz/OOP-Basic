﻿namespace MordorsCruelPlan.Moods
{
    public class Happy: MoodsS
    {
        public override string Name => "Happy";
    }
}
