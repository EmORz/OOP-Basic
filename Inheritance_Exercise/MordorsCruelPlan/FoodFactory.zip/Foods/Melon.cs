﻿using MordorCruelPlan.Foods;

namespace MordorsCruelPlan.Foods
{
    public class Melon : Food
    {
        private const int happiness = 1;

        public Melon() : base(happiness)
        {
        }
    }
}
