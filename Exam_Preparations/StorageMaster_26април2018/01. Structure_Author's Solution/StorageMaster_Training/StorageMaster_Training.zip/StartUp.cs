﻿using System;

namespace StorageMaster_Training
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

        }
    }
}
