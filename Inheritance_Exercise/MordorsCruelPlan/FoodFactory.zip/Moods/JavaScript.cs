﻿namespace MordorsCruelPlan.Moods
{
    public class JavaScript: MoodsS
    {
        public override string Name => "JavaScript";
    }
}
