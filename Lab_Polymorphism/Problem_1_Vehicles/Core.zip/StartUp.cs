﻿using Problem_1_Vehicles.Core;
using System;

namespace Problem_1_Vehicles
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
