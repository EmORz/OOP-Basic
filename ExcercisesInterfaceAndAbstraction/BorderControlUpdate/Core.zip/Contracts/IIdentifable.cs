﻿namespace BorderControlUpdate.Contracts
{
    public interface IIdentifable
    {
        string Id { get; }
    }
}
