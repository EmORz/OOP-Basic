﻿namespace MordorsCruelPlan.Moods
{
    public class Angry : MoodsS
    {
        public override string Name => "Angry";
    }
}
