﻿namespace BirthdayCelebrations.Contracts
{
    public interface IIdentity
    {
        string Id { get; }
    }
}
