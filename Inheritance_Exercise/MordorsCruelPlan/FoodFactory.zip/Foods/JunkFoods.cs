﻿using MordorCruelPlan.Foods;

namespace MordorsCruelPlan.Foods
{
    public class JunkFoods : Food
    {
        private const int happiness = -1;

        public JunkFoods() : base(happiness)
        {
        }
    }
}
