﻿namespace MordorsCruelPlan.Moods
{
    public class Sad : MoodsS
    {
        public override string Name => "Sad";
    }
}
