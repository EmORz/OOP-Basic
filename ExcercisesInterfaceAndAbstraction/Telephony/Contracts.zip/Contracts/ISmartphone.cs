﻿namespace Telephony.Contracts
{
    public interface ISmartphone : IPhone
    {
        string Browsing(string url);
    }
}
