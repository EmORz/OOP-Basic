﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem_1_Vehicles.Contracts
{
    public interface IRefuel
    {
        void Refuel(double quantity);
    }
}
