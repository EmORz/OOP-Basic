﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster_Training.Entities.Products
{
    public class HardDrive : Product
    {
        public HardDrive(double price) 
            : base(price, 1)
        {
        }
    }
}
