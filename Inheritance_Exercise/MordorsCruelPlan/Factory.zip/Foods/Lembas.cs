﻿using MordorCruelPlan.Foods;

namespace MordorsCruelPlan.Foods
{
    public class Lembas : Food
    {
        private const int happiness = 3;

        public Lembas() : base(happiness)
        {
        }
    }
}
