﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster_Training.Entities.Vechicles
{
    public class Van : Vehicle
    {
        public Van() 
            : base(capacity: 2)
        {
        }
    }
}
