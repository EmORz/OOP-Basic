﻿namespace SingleInheritance
{
    using System;


    public class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating");
        }
    }
}
